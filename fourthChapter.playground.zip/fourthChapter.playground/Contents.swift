//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// 2018-10-12
//------------------------4-1,Swift 2.0 逻辑控制之循环结构-------------------
/*
 控制流
 1,顺序结构
 2,循环结构
 3,选择结构
 
 */
//循环结构  for - in
for i in -99...99
{
    i*i
}

var result = 1
var base = 2
var  power = 10

// 下划线此处省略循环变量
for _ in 1...power
{
    result *= base
    
    
}
result

/* for 循环
 
 三部分的外面不需要使用括号,
 循环体只有一句代码时也需要使用大括号

 for initialization; condition; increments
 {
 statements
 }
 
 
 
 */

/*被禁止
for var m = -99; m <= 99; m++
{
    m * m
}
 
 
 var i = -99
 for ; i<=99
 {
 i * i
 i++
 }
 

 for var a = -6.28; a <= 6.28; a += 0.1
 {
 sin(a)
 }
 
 var index = -99
 var step = 1
 for ; index <=99 ; index += step
 {
 index * index
 step *= 2
 }
 
*/

//------------------------------4-2, Swift 2.0 逻辑控制之循环结构---------------------------
/*
 while 与 for 循环 可以等价相看
 
 
 initialization
 while conddition
 {
 statements
  increments
 }
 
 
 */

var  aWin = 0
var bWin = 0
var game = 0
while aWin < 3 && bWin < 3 {
//    game+=
}

// 0..<6 随机数
let a = arc4random_uniform(6)


/*
 do while 循环至少要执行一次循环
 
 repeat - while
 
 initialization
 repeat {
 statements
 increments
 
 }while condition
 
 */

var mWin = false
var nWin = false

//repeat{
//    let a = arc4random_uniform(6)+1
//    let b = arc4random_uniform(6)+1
////    print("a is \(a), b is \(b).",terminator:"")
//
//
//}

/*
 break 和continue
 
 break 立即结束当前的循环
 continue 结束当前循环体的内容直接进行下一次的循环
 
  */

while true {
    let a2 = arc4random_uniform(6)+1
    let b2 = arc4random_uniform(6)+1
    if a2 == b2 {
        print("draw")
        continue
    }
    let winner = a2 > b2 ? "A":"B"
    print("\(winner) win!")
    break
    
    
}

//-------------------------4-3 Swift2.0 逻辑控制之选择结构- if else 和 switch----------------------

/*
 选择结构
 
 if - else   -   else - if
 
 if condition
 {
 statements
 }
 else if condition2
 {
 statements
 }
 else
 {
 statements
 }
 */

let rating = "A"
if rating == "A"
{
    print("Great!")
}
else if rating == "B"
{
    print("Just so-so")
}
else if rating == "C"
{
    print("It is Bad")
}
else
{
    print("Error")
}

/*
 Switch
 
 switch some value to consider{
 case value1:
      respond to value1
 case value2:
      respond to value2
 case value3:
      respond to value3
 default:
    otherwise, do something else
 
 }
 
 
 swfit 语言中 switch 语句中不需要加break,  并且switch 条件变量不仅仅限于整型,此处两点与OC不同
 */

switch rating {
case "a","A":
    print("Great!")
case "B":
    print("Just so-so")
case "C":
    print("It is Bad")
default:
    print("Error")
    
//    当此处无输出时可用下方表示空输出
//    break/()
}


//当case为 true或false 时不需要default语句(因为此处可以穷举case条件)
let y1 = true
switch y1 {
case true:
    print("I am true")
case false:
    print("I am false")
}


//------------------------4-4,swift 2.0,逻辑控制之switch的高级用法--------------------------

let score = 90
switch score {
case 0:
    print("You got an egg")
case 1..<60:
    print("You failed")
case 60:
    print("Just passed")
case 61..<80:
    print("Just so-so")
case 80..<90:
    print("Good")
case 90..<100:
    print("Good")

default:
    print("Error score")
}

//(1,1) 元组
let vector = (1,1)
switch vector {
case (0,0):
    print("It is origin")
case (1,0):
    print("It an unit vector on the positive x-axis")
case (-1,0):
    print("It an unit vector on the negative x-axis")
case (0,1):
    print("It an unit vector on the positive y-axis")
case (0,-1):
    print("It an unit vector on the negative y-axis")
default:
    print("It is just an ordinary vector")
}


//下划线忽略元组中某一维度的数据
//在元组中针对某一维度的数据值也可以使用区间运算符
// fallthrough 关键字在执行完当前case语句时可跳入下个case语句
let point = (1,1)
switch point {
case (0,0):
    print("It is origin")
    fallthrough
case (_,0):
    print("It on the x-axis")
case (0,_):
    print("It on the y-axis")
case (-2...2,-2...2):
    print("It is near the origin")
default:
    print("It is just an ordinary point")
}

//let point1 = (1,1)
let point1 = (x:1,y:1)
//let point1: (x:Int , y:Int) = (1,1)
switch point {
case (0,0):
    print("It is origin")
case (_,0):
    print("(\(point1.x),\(point1.y)) is on the x-axis")
case (0,_):
   print("(\(point1.x),\(point1.y)) is on the y-axis")
case (-2...2,-2...2):
    print("(\(point1.x),\(point1.y)) is near the origin")
default:
    print("(\(point1.x),\(point1.y)) is just an ordinary point")
}



//该例子不需要default语句,因为case语句涵盖了所有情况
let point2 = (8,0)
switch point2 {
case (0,0):
    print("It is origin")
case (let x1,0):
    print("It on the x-axis")
    print("The x value is \(x1)")
case (0,let y1):
    print("It on the y-axis")
     print("The y value is \(y1)")
case (let x1,let y1):
    print("It is just an ordinary point")
    print("The point is (\(x1),\(y1)")

}

//--------------------------------4-5,Swift2.0 逻辑控制之控制转移------------------------

/*
 控制转移
 break
 continue
 fallthrough
 return
 throw
 
 */

// 求 x^4 - y^2 = 15*x*y 在300以内的一个正整数解

//双重循环


//var gotAnswer = false
//找到所有解
for m in 1...300
{
    for n in 1...300
    {
        if m*m*m*m - n*n == 15*m*n {
            print(m,n)
        }
    }
   
}


//找到一个解即退出
var gotAnswer = false
for m in 1...300
{
    for n in 1...300
    {
        if m*m*m*m - n*n == 15*m*n {
            print(m,n)
            gotAnswer = true
            break
    //            break 跳出当前n循环
        }
    }
    if gotAnswer {
        break
    }
}





for m in 1...300
{
    for n in 1...300
    {
        if m*m*m*m - n*n == 15*m*n {
            print(m,n)
            break
//            break 跳出当前n循环
        }
    }
    
}


//该形式同样适用于continue
findAnswer:for m in 1...300
{
    for n in 1...300
    {
        if m*m*m*m - n*n == 15*m*n {
            print(m,n)
            break findAnswer
//            跳出所有循环
        }
    }
    
}


//---------------------------------4-6,Swift2.0 逻辑控制之where与模式匹配--------------------------

/*
 where
 switch some value to consider
 {
 case value1:
      respond to value1
 case value2:
      respond to value2
 case value3:
      respond to value3
 default:
      otherwise, do something else
 }
 
 */

let point3 = (3,3)
switch point3 {
case let (x,y) where x==y:
    print("It is on the line x==y")
case let (x,y) where x == -y:
    print("It is on the line x==-y")
case let (x,y) :
    print("It is just an ordinary point")
    print("The point is (\(x),\(y)")

    
}



let age = 19
switch age {
case 10...19:
    print("You are teenager")
default:
    print("You are not teenager")
}


if case 10...19 = age{
    print("You are teenager")

}

/* ❓
if case 10...19 = age where age >= 18{
    print("You are teenager an in a college")

}


let vector = (4,0)
if case (let x ,0) = vector where x > 2 && x < 5
{
    print("It is the vector")
}
*/

for i in 1...100
{
    if i%3 == 0{
        print(i)
    }
}

for case  let i in 1...100 where i%3 == 0
{
    print(i)
}

//------------------------4-7, swift2.0 逻辑控制之guard 及代码风格初探-----------------------

/*
 guard continue else
 
 guard (关键字)确保一个条件为真
 定义一个函数用 func 后面加函数名
 */
func buy ( money:Int , price:Int, capacity:Int, volume:Int)
{
    if money >= price
    {
        if capacity >= volume
        {
            print("I can buy it")
            print("\(money-price) Yuan left")
            print("\(capacity-volume) cubic meters lett")
        }
        else
        {
            print("No enough capacity")
        }
    }
    else
    {
        print("Not enough money")
    }
}




func buy2 ( money:Int , price:Int, capacity:Int, volume:Int)

{
    guard money >= price else {
        print("Not enough money")
        return
    }
    guard capacity >= volume else
    {
        print("Not enough capacity")
        return
    }
    print("I can buy it")
    print("\(money-price) Yuan left")
    print("\(capacity-volume) cubic meters lett")
}






















